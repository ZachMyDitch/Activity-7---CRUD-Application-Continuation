<?php
    $query = "<<UPDATE SELECT QUERY>>";
    $result = mysqli_query($link, $query);
?>